# Independent review

Work alone and review only your assigned packet. Open cases.md and the accompanying source records.
For each of the 20 files read both briefings, inspect the cited evidence, and fill in the two rows in ratings.csv.
The source file and line appear beside each citation. Supporting history is in evidence.json.
Assess the help each briefing offers an analyst before an identity owner or provider has answered.
An unavailable briefing receives a zero for missing information and a one for usefulness.

Missing information (0–2): 0 = absent or misleading, 1 = generic but plausible, 2 = names a specific unresolved fact that matters to this investigation.
Usefulness (1–5): 1 = unusable, 2 = substantial rework, 3 = adequate starting point, 4 = actionable with minor checking, 5 = actionable and well prioritized with an appropriate caveat.
Equal scores are allowed. Note an example supporting your rating. Return your own completed ratings.csv to the study organizer before reading the results or discussing ratings.
